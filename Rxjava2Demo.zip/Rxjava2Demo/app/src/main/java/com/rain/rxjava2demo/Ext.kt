package com.rain.rxjava2demo

import android.util.Log

/**
 * Author:rain
 * Date:2019/1/15 16:03
 * Description:
 * Kotlin 扩展
 */
fun loge(tag:String,message:String){
    Log.e(tag,message)
}

